# HOT miner

A script to automatically mine HOT every 90 minutes.

## Setup

- Install Git here https://git-scm.com/book/en/v2/Getting-Started-Installing-Git
- Install Nodejs here https://nodejs.org/en, recommended download LTS version 20.11.0
- Clone repository `git clone https://github.com/asepkh/hot-miner-auto-claim.git`, login git first if needed, or you can download via zip.
- Run `cd ./hot-miner-auto-claim` (need to match the path of repo script)
- Install yarn via `npm i -g yarn`
- Install dependencies via running `yarn`
- Paste your multiple account ID and private key without the `ed25519:` prefix, to be execute hot miner auto claim in `wallets.json`

```sh
# example
[
  {
    "publicKey": "HOT_WALLET_PUBLIC_KEY_1, example: asepkh.near",
    "privateKey": "PRIVATE_KEY_1"
  },
  {
    "publicKey": "HOT_WALLET_PUBLIC_KEY_2, example: asepkh.near",
    "privateKey": "PRIVATE_KEY_2"
  },
  {
    "publicKey": "ANOTHER_MULTIPLE_FOLLOW_THIS_PATTERN",
    "privateKey": "..."
  }
]
```

## Run

Run for check HOT claim by manual claim:

```sh
yarn test
```

Run auto claim every 90 minutes:

```sh
yarn start
```

## Update latest script (if there's updates needed)

Update script to the latest version

```sh
git pull -u origin main
```
