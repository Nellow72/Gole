const main = require('./main.cjs');

main();
